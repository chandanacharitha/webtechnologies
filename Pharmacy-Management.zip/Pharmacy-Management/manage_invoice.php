<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Manage Invoice</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/icon.svg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/home.css">
    <script src="js/manage_invoice.js"></script>
    <script src="js/restrict.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  </head>
  <body>
    <!-- including side navigations -->
    <?php include("sections/sidenav.html"); ?>

    <div class="container-fluid">
      <div class="container">

        <!-- header section -->
        <?php
          require "php/header.php";
          createHeader('address-book', 'Manage Invoice', 'Manage Existing Invoice');
        ?>
        <!-- header section end -->

        <!-- form content -->
        <div class="row">

          <div class="col-md-12 form-group form-inline">
            <label class="font-weight-bold" for="">Search :&emsp;</label>
            <input type="number" class="form-control" id="by_invoice_number" placeholder="By Invoice Number" onkeyup="searchInvoice(this.value, 'INVOICE_ID');">
            &emsp;<input type="text" class="form-control" id="by_customer_name" placeholder="By Customer Name" onkeyup="searchInvoice(this.value, 'NAME');">
            &emsp;<label class="font-weight-bold" for="">By Invoice Date :&emsp;</label>
            <input type="date" class="form-control" id="by_date" onchange="searchInvoice(this.value, 'INVOICE_DATE');">
            &emsp;<button class="btn btn-success font-weight-bold" onclick="refresh();"><i class="fa fa-refresh"></i></button>
          </div>

          <div class="col col-md-12">
            <hr class="col-md-12" style="padding: 0px; border-top: 2px solid  #02b6ff;">
          </div>
          <?php
            require 'php/db_connection.php'; // Include your database connection file

            // Retrieve data from the database table `invoices`
            $query = "SELECT MONTH(INVOICE_DATE) AS month, IFNULL(SUM(TOTAL_AMOUNT), 0) AS amount FROM invoices GROUP BY month ORDER BY month ASC";
            $result = mysqli_query($con, $query);

            // Initialize an associative array to store the retrieved data
            $monthsData = array();

            // Populate the array with all 12 months
            for ($i = 1; $i <= 12; $i++) {
                $monthsData[$i] = 0;
            }

            // Fetch the data and update the corresponding month's amount
            while ($row = mysqli_fetch_assoc($result)) {
                $month = $row['month'];
                $amount = $row['amount'];
                // Update the month's amount in the array
                $monthsData[$month] = $amount;
            }

            // Extract the months and amounts from the associative array
            $months = array_keys($monthsData);
            $amounts = array_values($monthsData);
          ?>
          <h4 style="text-align:center">THIS CHART DISPLAYS INVOICE BY MONTH ON THE X-AXIS AND THE AMOUNT ON THE Y-AXIS</h4>
          <div style="width: 450px">
            <canvas id="Invoice_Chart"></canvas>
          </div>
          <script>
            var ctx = document.getElementById('Invoice_Chart').getContext('2d');

            // Create the bar graph using Chart.js
            var chartData = {
              labels: <?php echo json_encode($months); ?>,
              datasets: [{
                label: 'Amount',
                data: <?php echo json_encode($amounts); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.5)', // Example color
                borderColor: 'rgba(75, 192, 192, 1)', // Example border color
                borderWidth: 2, // Example border width
                hoverBackgroundColor: 'rgba(75, 192, 192, 0.8)', // Example hover background color
                hoverBorderColor: 'rgba(75, 192, 192, 1)',
              }]
            };

            var barChart = new Chart(ctx, {
              type: 'bar',
              data: chartData,
              options: {
                responsive: true,
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      stepSize: 500
                    }
                  }
                }
              }
            });
          </script>

          <div class="col col-md-12 table-responsive">
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-hover">
                <thead>
                  <tr>
                    <th>SL.</th>
                    <th>Invoice No</th>
                    <th>Customer Name</th>
                    <th>Date</th>
                    <th>Total Amount</th>
                    <th>Total Discount</th>
                    <th>Net Total</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="invoices_div">
                  <?php
                    require 'php/manage_invoice.php';
                    showInvoices();
                  ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
        <!-- form content end -->
        <hr style="border-top: 2px solid #ff5252;">
      </div>
    </div>
  </body>
</html>

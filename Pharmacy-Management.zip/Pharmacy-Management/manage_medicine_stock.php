<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Manage Medicines Stock</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/icon.svg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/home.css">
    <script src="js/manage_medicine_stock.js"></script>
    <script src="js/validateForm.js"></script>
    <script src="js/restrict.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  </head>
  <body>
    <!-- including side navigations -->
    <?php include("sections/sidenav.html"); ?>

    <div class="container-fluid">
      <div class="container">
        <!-- header section -->
        <?php
         

          function createHeader($icon, $pageTitle, $pageSubTitle) {
            echo '<div class="row">';
            echo '<div class="col-md-3">';
            echo '<h1><i class="fa fa-'.$icon.'"></i> '.$pageTitle.'</h1>';
            echo '</div>';
            echo '<div class="col-md-9">';
            echo '<h6 class="my-sub-title">'.$pageSubTitle.'</h6>';
            echo '</div>';
            echo '</div>';
          }

          createHeader('shopping-bag', 'Manage Medicines Stock', 'Manage Existing Medicine Stock');
        ?>
        <!-- header section end -->

        <!-- form content -->
        <div class="row">
          <div class="col-md-12 form-group form-inline">
            <label class="font-weight-bold" for="">Search :&emsp;</label>
            <input type="text" class="form-control" id="by_name" placeholder="By Medicine Name" onkeyup="searchMedicineStock(this.value, 'NAME');">
            &emsp;<input type="text" class="form-control" id="by_generic_name" placeholder="By Generic Name" onkeyup="searchMedicineStock(this.value, 'GENERIC_NAME');">
            &emsp;<input type="text" class="form-control" id="by_suppliers_name" placeholder="By Supplier Name" onkeyup="searchMedicineStock(this.value, 'SUPPLIER_NAME');">
            &emsp;<button class="btn btn-danger font-weight-bold" onclick="searchMedicineStock('0', 'QUANTITY');">Out of Stock</button>
            &emsp;<button class="btn btn-warning font-weight-bold" onclick="searchMedicineStock('', 'EXPIRY_DATE');">Expired</button>
            &emsp;<button class="btn btn-success font-weight-bold" onclick="cancel();"><i class="fa fa-refresh"></i></button>
          </div>
          <div class="col col-md-12">
            <hr class="col-md-12" style="padding: 0px; border-top: 2px solid  #02b6ff;">
          </div>
          <div class="col col-md-12 table-responsive">
            <div class="table-responsive">
            <?php
              require 'php/db_connection.php'; // Include your database connection file

              // Retrieve data from the database table `medicine_stock`
              $query = "SELECT NAME, BATCH_ID, EXPIRY_DATE, QUANTITY, MRP, RATE FROM medicines_stock";
              $result = mysqli_query($con, $query);
              $que="SELECT PACKING,GENERIC_NAME,SUPPLIER_NAME FROM medicines";
              $resultis=mysqli_query($con,$que);
              // Initialize arrays to store the retrieved data
              $medicineNames = array();
              $packing=array();
              $supplier=array();
              $generic_name=array();
              $batchIds = array();
              $expiryDates = array();
              $quantities = array();
              $mrps = array();
              $rates = array();

              // Fetch the data and populate the arrays
              while ($row = mysqli_fetch_assoc($result)) {
                $medicineNames[] = $row['NAME'];        
                $batchIds[] = $row['BATCH_ID'];
                $expiryDates[] = $row['EXPIRY_DATE'];   
                $quantities[] = $row['QUANTITY'];
                $mrps[] = $row['MRP'];
                $rates[] = $row['RATE'];
              }
              while ($rows = mysqli_fetch_assoc($resultis)) {
                $generic_name[] = $rows['GENERIC_NAME'];   
                $packing[]=$rows['PACKING'];
                $supplier[]=$rows['SUPPLIER_NAME'];     
                
              }

              ?>
            <h4 style="text-align:center">THIS CHART DISPLAYS NAME OF THE MEDICINE ON THE X-AXIS AND THE QUANTITY AVAILABLE ON THE Y-AXIS</h4>
           <div style="width: 450px">
            <canvas id="medicineChart"></canvas>
            </div>
              <script>
                var ctx = document.getElementById('medicineChart').getContext('2d');

                // Create the bar graph using Chart.js
                var chartData = {
                  labels: <?php echo json_encode($medicineNames); ?>,
                  datasets: [{
                    label: 'Stock Quantity',
                    data: <?php echo json_encode($quantities); ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)', // Example color
                    borderColor: 'rgba(75, 192, 192, 1)', // Example border color
                    borderWidth: 2, // Example border width
                    hoverBackgroundColor: 'rgba(75, 192, 192, 0.8)', // Example hover background color
                    hoverBorderColor: 'rgba(75, 192, 192, 1)',
                  }]
                };

                var barChart = new Chart(ctx, {
                  type: 'bar',
                  data: chartData,
                  options: {
                    responsive: true,
                    
                    scales: {
                      y: {
                        beginAtZero: true,
                        ticks: {
                          stepSize: 1
                        }
                      }
                    }
                  }
                });
              </script>  

              
              <table class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th style="width: 1%;">SL.</th>
                  <th style="width: 14%;">Medicine Name</th>
                  <th style="width: 5%;">Packing</th>
                  <th style="width: 14%;">Generic Name</th>
                  <th style="width: 10%;">Batch ID</th>
                  <th style="width: 8%;">Ex. Date (mm/yy)</th>
                  <th style="width: 15%;">Supplier</th>
                  <th style="width: 7%;">Qty.</th>
                  <th style="width: 8%;">M.R.P.</th>
                  <th style="width: 8%;">Rate</th>
                  <th style="width: 10%;">Actions</th>
                </tr>
              </thead>
              <tbody id="medicines_stock_div">
                <?php
                  //Loop through the retrieved data and generate table rows
                  for ($i = 0; $i < count($medicineNames); $i++) {
                    echo "<tr>";
                    echo "<td>" . ($i + 1) . "</td>";
                    echo "<td  class='medicine-name'>" . $medicineNames[$i] . "</td>";
                    echo "<td  class='packing'>" . $packing[$i] . "</td>";
                    echo "<td  class='generic-name'>" . $generic_name[$i] . "</td>";
                    echo "<td class='batch-id'>" . $batchIds[$i] . "</td>";
                    echo "<td class='expiry-date'>" . $expiryDates[$i] . "</td>";
                    echo "<td class='supplier'>" . $supplier[$i] . "</td>";
                    echo "<td class='quantity'>" . $quantities[$i] . "</td>";
                    echo "<td  class='mrp'>" . $mrps[$i] . "</td>";
                    echo "<td class='rate'>" . $rates[$i] . "</td>";
                    echo "<td><button class='btn btn-primary update-btn' onclick='editMedicineStock(this)'>Update</button></td>";
                    echo "</tr>";
                  }
                  
                ?>
              </tbody>

            </table>

            </div>
          </div>
        </div>
        <!-- form content end -->
        <hr style="border-top: 2px solid #ff5252;">
      </div>
    </div>
    <script>
  // Handle click event of the update button
  $(document).on('click', '.update-btn', function(e) {
    e.preventDefault();

    // Retrieve the updated medicine details from the table row
    var row = $(this).closest('tr');
    var medicineID = row.index(); // Index of the row in the table
    var medicineName = row.find('.medicine-name').text();
    var packing = row.find('.packing').text();
    var genericName = row.find('.generic-name').text();
    var batchID = row.find('.batch-id').text();
    var expiryDate = row.find('.expiry-date').text();
    var supplier = row.find('.supplier').text();
    var quantity = row.find('.quantity').text();
    var mrp = row.find('.mrp').text();
    var rate = row.find('.rate').text();
    $sql="update medicines set NAME=medicineName ,PACKING=packing ,GENERIC_NAME=genericName ,SUPPLIER_NAME=supplier";
    $sql1="update medicines_stock set NAME=medicineName , BATCH_ID=batchID ,QUANTITY=quantity ,EXPIRY_DATE=expiryDate ,MRP=mrp ,RATE=rate";
    $res1=mysqli_query($con,$sql);
    $res2=mysqli_query($con,$sql1);

  });
    </script>
  </body>
</html>
